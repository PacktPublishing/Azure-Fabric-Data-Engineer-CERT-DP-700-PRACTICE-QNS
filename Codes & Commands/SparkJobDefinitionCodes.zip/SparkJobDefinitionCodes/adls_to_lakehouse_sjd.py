from pyspark.sql import SparkSession
import sys

spark = SparkSession.builder.appName('sjd_1_adls_to_lakehouse').getOrCreate()

client_id = "xxxx"
client_secret = "xxxx"
tenant_id = "xxxx"

spark.conf.set("fs.azure.account.auth.type.3aayaamfabricstorageacc.dfs.core.windows.net", "OAuth")
spark.conf.set("fs.azure.account.oauth.provider.type.3aayaamfabricstorageacc.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
spark.conf.set("fs.azure.account.oauth2.client.id.3aayaamfabricstorageacc.dfs.core.windows.net", client_id)
spark.conf.set("fs.azure.account.oauth2.client.secret.3aayaamfabricstorageacc.dfs.core.windows.net", client_secret)
spark.conf.set("fs.azure.account.oauth2.client.endpoint.3aayaamfabricstorageacc.dfs.core.windows.net", f"https://login.microsoftonline.com/{tenant_id}/oauth2/token")

if len(sys.argv) > 0:
    adls_src_container = sys.argv[1].replace('"', '')
    adls_src_dir = sys.argv[2].replace('"', '')
    lakehouse_dest_table = sys.argv[3].replace('"', '')

    df1 = spark.read.format('csv').option('header','true').option('inferSchema','true')\
        .load(f"abfss://{adls_src_container}@3aayaamfabricstorageacc.dfs.core.windows.net/{adls_src_dir}")

    df1.write.format('delta').saveAsTable(f"{lakehouse_dest_table}")
