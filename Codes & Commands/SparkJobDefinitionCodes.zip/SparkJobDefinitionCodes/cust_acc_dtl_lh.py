from pyspark.sql import SparkSession

spark = SparkSession.builder.appName('sjd_2_cust_acct_dtl_lh').getOrCreate()

client_id = "xxxx"
client_secret = "xxxx"
tenant_id = "xxxx"

spark.conf.set("fs.azure.account.auth.type.3aayaamfabricstorageacc.dfs.core.windows.net", "OAuth")
spark.conf.set("fs.azure.account.oauth.provider.type.3aayaamfabricstorageacc.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
spark.conf.set("fs.azure.account.oauth2.client.id.3aayaamfabricstorageacc.dfs.core.windows.net", client_id)
spark.conf.set("fs.azure.account.oauth2.client.secret.3aayaamfabricstorageacc.dfs.core.windows.net", client_secret)
spark.conf.set("fs.azure.account.oauth2.client.endpoint.3aayaamfabricstorageacc.dfs.core.windows.net", f"https://login.microsoftonline.com/{tenant_id}/oauth2/token")


cust_lh = spark.read.table('cust_lh').select('customer_id','first_name','last_name','email','country')
acct_lh = spark.read.table('acct_lh').select('customer_id','account_id','balance')

df1 = cust_lh.join(acct_lh, cust_lh.customer_id == acct_lh.customer_id, 'inner')\
    .drop(acct_lh.customer_id)

df1.write.format('delta').saveAsTable('cust_acct_dtl_lh')

















